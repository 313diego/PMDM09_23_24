package com.cidead.pmdm.tareaut09_permisosdiegomanuel;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final int PER_READ_CONTACTS = 1;
    private static final int PERMISOS_MULTIPLES = 2;
    EditText eTTlf, eTMsj;
    Button bTContacto, bTEnviar;

protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    eTTlf = (EditText) findViewById(R.id.eTTelefono);
    eTMsj = (EditText) findViewById(R.id.eTMensaje);
    bTContacto = (Button) findViewById(R.id.bTContacto);
    bTEnviar = (Button) findViewById(R.id.bTEnviar);
    bTContacto.setOnClickListener(this);
    bTEnviar.setOnClickListener(this);

    // Solicitar ambos permisos al mismo tiempo
    if (!comprPermisos(android.Manifest.permission.SEND_SMS) ||
            !comprPermisos(android.Manifest.permission.READ_CONTACTS)) {
        ActivityCompat.requestPermissions(this,
                new String[]{android.Manifest.permission.SEND_SMS, android.Manifest.permission.READ_CONTACTS},
                PERMISOS_MULTIPLES);
    }
}

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISOS_MULTIPLES) {
            // Verificar si los permisos fueron concedidos
            for (int i = 0; i < permissions.length; i++) {
                if (permissions[i].equals(android.Manifest.permission.SEND_SMS)) {
                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(this, "El permiso de enviar mensajes ha sido concedido", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "No dispone de permisos para enviar mensajes", Toast.LENGTH_SHORT).show();
                    }
                } else if (permissions[i].equals(android.Manifest.permission.READ_CONTACTS)) {
                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(this, "El permiso de acceso a contactos ha sido concedido", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "No dispone depermisos para acceder a los contactos", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.bTContacto){
            if (comprPermisos(android.Manifest.permission.READ_CONTACTS)) {
                Intent i = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
                startActivityForResult(i, PER_READ_CONTACTS);
            } else {
                if(!comprPermisos(android.Manifest.permission.READ_CONTACTS)){
                    ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.READ_CONTACTS}, PER_READ_CONTACTS);
                }
            }

        }if(v.getId()==R.id.bTEnviar){
            String numeroTelefono = eTTlf.getText().toString();
            String mensaje = eTMsj.getText().toString();
            if(!TextUtils.isEmpty(numeroTelefono)&&!TextUtils.isEmpty(mensaje)){
                if(ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.SEND_SMS)!= PackageManager.PERMISSION_GRANTED){
                    return;
                }
                SmsManager enviar = SmsManager.getDefault();
                enviar.sendTextMessage(numeroTelefono, null, mensaje, null, null);
                eTTlf.setText("");
                eTMsj.setText("");
                Toast.makeText(this, "El mensaje ha sido enviado!", Toast.LENGTH_SHORT).show();
            }else{
                if(numeroTelefono.isEmpty()){
                    Toast.makeText(this, "Introduce un número de telefono", Toast.LENGTH_SHORT).show();
                }
                if(mensaje.isEmpty()){
                    Toast.makeText(this, "Introduce el mensaje", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
    // Controlamos los permisos
    private boolean comprPermisos(String permission){
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED;
    }
    // Recoger contacto de la agenda
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PER_READ_CONTACTS && resultCode == RESULT_OK){
            if(data != null){
                Uri contactos = data.getData();
                if(contactos != null){
                    String id = contactos.getLastPathSegment();
                    mostrarContacto(id);
                }
            }
        }
    }
    // Mostramos el contacto
    public void mostrarContacto(String contactoSeleccionado){
        String [] contacto = new String[]{
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER
        };
        ContentResolver contentResolver = getContentResolver();
        Cursor cursor = contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, contacto, ContactsContract.CommonDataKinds.Phone.CONTACT_ID+" = ?", new String[]{contactoSeleccionado}, null);
        if(cursor != null && cursor.moveToFirst()){
            @SuppressLint("Range") String nombre = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
            @SuppressLint("Range") String tlf = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
            eTMsj.setText(nombre);
            eTTlf.setText(tlf);
        }
        cursor.close();
    }
}